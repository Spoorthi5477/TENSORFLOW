import argparse
import sys
import time

import cv2
from tflite_support.task import core
from tflite_support.task import processor
from tflite_support.task import vision

# Visualization parameters
_ROW_SIZE = 20  # pixels
_LEFT_MARGIN = 24  # pixels
_TEXT_COLOR = (0, 0, 255)  # red
_FONT_SIZE = 3
_FONT_THICKNESS = 3

ap = argparse.ArgumentParser()
ap.add_argument("-m", "--model", type=str, default='model/model.tflite', help="path to model")
args = vars(ap.parse_args())

def main():
    # Initialize the image classification model
    base_options = core.BaseOptions(file_name=args["model"], use_coral=False, num_threads=4)
    classification_options = processor.ClassificationOptions(max_results=1, score_threshold=0.8)
    options = vision.ImageClassifierOptions(base_options=base_options, classification_options=classification_options)
    classifier = vision.ImageClassifier.create_from_options(options)
  
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Cannot open camera")
        exit()
    time.sleep(2)

    while True:
        # Capture frame-by-frame
        ret, frame = cap.read()
        # if frame is read correctly ret is True
        if not ret:
            print("Can't receive frame (stream end?). Exiting ...")
            break
        # Our operations on the frame come here
        # gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
        # Display the resulting frame
        image = frame

        # Convert the image from BGR to RGB as required by the TFLite model.
        rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # Create a TensorImage object from the RGB image.
        tensor_image = vision.TensorImage.create_from_array(rgb_image)

        categories = classifier.classify(tensor_image)
        # Show classification results on the image
        for idx, category in enumerate(categories.classifications[0].categories):
            category_name = category.category_name
            score = round(category.score, 2)
            result_text = category_name + ' (' + str(score) + ')'
            #print (result_text)
            text_location = (_LEFT_MARGIN, (idx + 2) * _ROW_SIZE)
            cv2.putText(image, result_text, text_location, cv2.FONT_HERSHEY_PLAIN, _FONT_SIZE, _TEXT_COLOR, _FONT_THICKNESS)
        cv2.imshow('image_classification', image)
        if cv2.waitKey(1) == ord('q'):
            break
    cap.release()    
    cv2.destroyAllWindows()

if __name__ == '__main__':
  main()


